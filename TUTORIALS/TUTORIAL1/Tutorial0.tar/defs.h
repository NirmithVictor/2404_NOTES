void initArray(int*);
void printArray(int*);
bool checkNum(int);
void doubleNum(int&);
int  random(int);

#define MAX_ARR_SIZE  16

